public class FixedAccount {
    int tenureYear;

    public int getTenureYear() {
        return tenureYear;
    }

    public void setTenureYear(int tenureYear) {
        this.tenureYear = tenureYear;
    }
    
    
}