public interface CustomerOperations {
    public void insertCustomer(Customer C);
    public void removeCustomer(Customer C);
    Customer getCustomer(int nid);
    public void showAllCustomers();
}