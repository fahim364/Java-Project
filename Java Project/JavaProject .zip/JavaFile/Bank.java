public class Bank {
   
    Customer Customers[];
    Employee Employees[];
    public Bank(){
       
    }
    
}
