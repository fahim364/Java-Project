import java.util.Scanner;
public class Start{

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println(" 1.Employee Manangement "
                + "\n 2.Customer Managemnet "
                + "\n 3.Customer Account Management "
                + "\n 4.Account Transactions "
                + "\n 5.Exit"
                + "");
        System.out.print("Enter which one you want to perform: ");
        int user_input = sc.nextInt();

        switch (user_input) {

            case 1:
                int u_input1;
                Scanner sc1 = new Scanner(System.in);
                System.out.println("1.Insert new Employee "
                        + "\n 2.Remove Existing Employee "
                        + "\n 3.Show all Employee ");
                u_input1 = sc1.nextInt();
                switch (u_input1) {
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    default:
                        System.out.println("Invalid Input!");

                }

                break;
            case 2:
                
                int u_input2;
                Scanner sc2 = new Scanner(System.in);
                System.out.println("1.Insert new Customer "
                        + "\n 2.Remove Existing Customer "
                        + "\n 3.Show all Customer ");
                u_input2 = sc2.nextInt();
                switch (u_input2) {
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    default:
                        System.out.println("Invalid Input!");
                }
                break;
            case 3:
                
                int u_input3;
                Scanner sc3 = new Scanner(System.in);
                System.out.println("1.Insert new Account "
                        + "\n 2.Remove Existing Account "
                        + "\n 3.Show all Account ");
                u_input3 = sc3.nextInt();
                switch (u_input3) {
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    default:
                        System.out.println("Invalid Input!");

                }
                break;
            case 4:
                
                int u_input4;
                Scanner sc4 = new Scanner(System.in);
                System.out.println("1.Deposit Money "
                        + "\n 2.Withdraw Money "
                        + "\n 3.Tarnsfer Money ");
                u_input4 = sc4.nextInt();
                switch (u_input4) {
                    case 1:
                        break;
                    case 2:
                        break;
                    case 3:
                        break;
                    default:
                        System.out.println("Invalid Input!");

                }
                break;
            case 5:
                break;

            default:
                System.out.println("Invalid Input");
        }

    }

}
